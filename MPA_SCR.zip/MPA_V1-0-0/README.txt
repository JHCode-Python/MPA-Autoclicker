This program is very much a work in progress, so expect some small bugs and the occasional crash.

If you do find a fatal error or a bug, please comment about it on the github page.

Install instructions:

Download zip folder
Unpack at desired location
open folder and dist, and double click .exe file to start

Rambling:

This program opens two icons, the main window, and a console that is minimized.
The console is required to run the program, however it does not require to be seen.

The reason there are two is Windows doesn't like apps that close the console and run a gui without the code being signed. Unfortunately, to sign the code requires a vaild (legal) company, and a $250 yearly subscription to a signing company. I am both not experienced enough at this time, nor do I have that kind of disposable income. The horrors of a hobbyist programmer >_<, lol.


I do have plans to improve this by a large margin, but I have no way of knowing when that will happen or how long that will take.