import pyautogui as pya
import time as ti
import keyboard as key
import threading as thr
import tkinter as tk
import sys
import ctypes
import pyperclip as pyp

##########################################################
# failsafe deactivation

def failsafe_temp_deact():
    try:
        pya.FAILSAFE = False
        ti.sleep(.5)
        pya.FAILSAFE = True
    except:
        pass

##########################################################
# main flags

e_stop = False
restart_flag = False
stop_message_printed = True

auto_thread = None

mouse_loc_x = 100
mouse_loc_y = 100

sleep_duration = 1.0

screen_width, screen_height = pya.size()
middle_pos = screen_width // 2, screen_height // 2

current_mouse_pos = (100, 100)

copied_coords = 100, 100
window_focused = True

coord_states = [False] * 10
coord_buttons = []

##########################################################
# opening banner

open_banner = '''
     _ _   _  ____          _      
    | | | | |/ ___|___   __| | ___ 
 _  | | |_| | |   / _ \ / _` |/ _ |
| |_| |  _  | |__| (_) | (_| |  __/
 \___/|_| |_|\____\___/ \__,_|\___|
 '''

# What are you doing rummaging around in here eh?
# send me a dm of an apple emoji for a gold star

##########################################################
# middle_pos default startup location

pya.moveTo(middle_pos)

##########################################################
# base variables

point1 = middle_pos
point2 = middle_pos
point3 = middle_pos
point4 = middle_pos
point5 = middle_pos
point6 = middle_pos
point7 = middle_pos
point8 = middle_pos
point9 = middle_pos
point10 = middle_pos

##########################################################
# click coordinates

coords = [
    (point1),
    (point2),
    (point3),
    (point4),
    (point5),
    (point6),
    (point7),
    (point8),
    (point9),
    (point10)
]

##########################################################
# small functions

def disable_enter(event):
    return "break"

def disable_typing(event):
    return "break"

def toggle_pause():
    global e_stop
    e_stop = True

##########################################################
# main function(s)

def auto_scr():
    global e_stop, stop_message_printed
    try:
        alt_flag = True
        while not e_stop:
            for i, (x, y) in enumerate(coords):
                if coord_states[i]:
                    alt_char = '-' if alt_flag else '--'
                    print(f"Moving to: x={x}, y={y} {alt_char}")
                    alt_flag = not alt_flag
                    pya.moveTo(x, y)
                    pya.click(x, y)
                    ti.sleep(sleep_duration)
                    if e_stop:
                        break
        if not stop_message_printed and e_stop:
            stop_message_printed = True
            print('Paused script due to F6...')

    except KeyboardInterrupt:
        pass
    except UnboundLocalError:
        pass

def get_mouse_pos():
    global mouse_loc_x, mouse_loc_y, screen_width, screen_height, middle_pos, mouse_loc_main
    try:
        while True:
            x, y = pya.position()
            screen_width, screen_height = pya.size()
            mouse_loc_x = x
            mouse_loc_y = y
            mouse_loc_main = mouse_loc_x, mouse_loc_y
            middle_x = screen_width // 2
            middle_y = screen_height // 2
            middle_pos = middle_x, middle_y
            ti.sleep(0.1)
    except KeyboardInterrupt:
        pass

def toggle_coord_state(coord_index):
    global coord_states
    coord_states[coord_index] = not coord_states[coord_index]
    if coord_states[coord_index]:
        coord_buttons[coord_index].config(bg='green')
        print(f"Coordinate {coord_index + 1} is now enabled.")
    else:
        coord_buttons[coord_index].config(bg='red')
        print(f"Coordinate {coord_index + 1} is now disabled.")

##########################################################
# update coord boxes on startup

def update_coord_text_boxes():
    global middle_pos
    coord_1_box.delete('1.0', tk.END)
    coord_1_box.insert(tk.END, f'{middle_pos[0]}, {middle_pos[1]}')
    coord_2_box.delete('1.0', tk.END)
    coord_2_box.insert(tk.END, f'{middle_pos[0]}, {middle_pos[1]}')
    coord_3_box.delete('1.0', tk.END)
    coord_3_box.insert(tk.END, f'{middle_pos[0]}, {middle_pos[1]}')
    coord_4_box.delete('1.0', tk.END)
    coord_4_box.insert(tk.END, f'{middle_pos[0]}, {middle_pos[1]}')
    coord_5_box.delete('1.0', tk.END)
    coord_5_box.insert(tk.END, f'{middle_pos[0]}, {middle_pos[1]}')
    coord_6_box.delete('1.0', tk.END)
    coord_6_box.insert(tk.END, f'{middle_pos[0]}, {middle_pos[1]}')
    coord_7_box.delete('1.0', tk.END)
    coord_7_box.insert(tk.END, f'{middle_pos[0]}, {middle_pos[1]}')
    coord_8_box.delete('1.0', tk.END)
    coord_8_box.insert(tk.END, f'{middle_pos[0]}, {middle_pos[1]}')
    coord_9_box.delete('1.0', tk.END)
    coord_9_box.insert(tk.END, f'{middle_pos[0]}, {middle_pos[1]}')
    coord_10_box.delete('1.0', tk.END)
    coord_10_box.insert(tk.END, f'{middle_pos[0]}, {middle_pos[1]}')

##########################################################
# emergency stop

def e_stop_act():
    global e_stop, restart_flag, stop_message_printed
    while True:
        key.wait('f6')
        e_stop = True
        stop_message_printed = False
        while e_stop:
            key.wait('f7')
            e_stop = False
            restart_flag = True
            print('Resuming script... ')
            break

##########################################################
# terminal redirect

class StdoutRedirector:
    def __init__(self, text_widget):
        self.text_widget = text_widget

    def write(self, output):
        self.text_widget.insert(tk.END, output)
        self.text_widget.see(tk.END)

    def flush(self):
        pass

##########################################################
# threading control

def start_threads():
    global auto_thread, stop_message_printed, sleep_duration, point1, coords

    #############################
    # sleep duration convert

    sleep_duration_str = time_text.get('1.0', tk.END).strip()

    if sleep_duration_str == '' or sleep_duration_str == '.' or sleep_duration_str == '/':
        sleep_duration = 1.0
    else:
        sleep_duration = float(sleep_duration_str)

    #############################
    # coord box 1 convert

    coord_1_box_str = coord_1_box.get('1.0', tk.END).strip()
    try:
        point1 = tuple(map(int, coord_1_box_str.split(',')))
    except ValueError:
        point1 = (middle_pos)

    coords[0] = point1

    coord_2_box_str = coord_2_box.get('1.0', tk.END).strip()
    try:
        point2 = tuple(map(int, coord_2_box_str.split(',')))
    except ValueError:
        point2 = (middle_pos)
    coords[1] = point2

    coord_3_box_str = coord_3_box.get('1.0', tk.END).strip()
    try:
        point3 = tuple(map(int, coord_3_box_str.split(',')))
    except ValueError:
        point3 = (middle_pos)
    coords[2] = point3

    coord_4_box_str = coord_4_box.get('1.0', tk.END).strip()
    try:
        point4 = tuple(map(int, coord_4_box_str.split(',')))
    except ValueError:
        point4 = (middle_pos)
    coords[3] = point4

    coord_5_box_str = coord_5_box.get('1.0', tk.END).strip()
    try:
        point5 = tuple(map(int, coord_5_box_str.split(',')))
    except ValueError:
        point5 = (middle_pos)
    coords[4] = point5

    coord_6_box_str = coord_6_box.get('1.0', tk.END).strip()
    try:
        point6 = tuple(map(int, coord_6_box_str.split(',')))
    except ValueError:
        point6 = (middle_pos)
    coords[5] = point6

    coord_7_box_str = coord_7_box.get('1.0', tk.END).strip()
    try:
        point7 = tuple(map(int, coord_7_box_str.split(',')))
    except ValueError:
        point7 = (middle_pos)
    coords[6] = point7

    coord_8_box_str = coord_8_box.get('1.0', tk.END).strip()
    try:
        point8 = tuple(map(int, coord_8_box_str.split(',')))
    except ValueError:
        point8 = (middle_pos)
    coords[7] = point8

    coord_9_box_str = coord_9_box.get('1.0', tk.END).strip()
    try:
        point9 = tuple(map(int, coord_9_box_str.split(',')))
    except ValueError:
        point9 = (middle_pos)
    coords[8] = point9

    coord_10_box_str = coord_10_box.get('1.0', tk.END).strip()
    try:
        point10 = tuple(map(int, coord_10_box_str.split(',')))
    except ValueError:
        point10 = (middle_pos)
    coords[9] = point10

    #############################

    if not stop_message_printed:
        stop_message_printed = True

    if auto_thread and auto_thread.is_alive():
        e_stop = True
        auto_thread.join()

    auto_thread = thr.Thread(target=auto_scr, daemon=True)
    auto_thread.start()

##########################################################
# main script loop

def main_loop():
    global restart_flag
    if restart_flag or not auto_thread.is_alive():
        restart_flag = False
        start_threads()
    window.update_idletasks()
    window.update()
    window.after(100, main_loop)

##########################################################
# focus window printing and flags

def on_focus_in(event):
    global window_focused, prev_window_focused
    prev_window_focused = window_focused
    window_focused = True
    if not prev_window_focused:
        print("Window focused...")

def on_focus_out(event):
    global window_focused, prev_window_focused
    prev_window_focused = window_focused
    window_focused = False
    if prev_window_focused:
        print("Window not focused...")

##########################################################
# copy coords to clipboard

def copy_coords(event):
    try:
        global e_stop, window_focused, mouse_loc_main, copied_coords
        if e_stop and window_focused:
            copied_coords = mouse_loc_main
            pyp.copy(str(mouse_loc_main)[1:-1])
            print(f'Coords :{mouse_loc_main}: copied to clipboard...')
    except Exception as e:
        print(f'An error has occurred while copying: {e}\nPlease try again...')

def paste_coords(event):
    global e_stop, window_focused, mouse_loc_main
    if e_stop and window_focused:
        print(f'Coords :{copied_coords}: pasted...')

##########################################################
# GUI

window = tk.Tk()
window.title("Multi-point : Precise Autoclicker : V1.0.0")

window.geometry("400x700")
window.resizable(False, False)

window.attributes('-topmost', True)

##########################################################
# focus checks

window.bind("<FocusIn>", on_focus_in)
window.bind("<FocusOut>", on_focus_out)

window.bind('<Control-c>', copy_coords)
window.bind('<Control-v>', paste_coords)

##########################################################
# terminal redirect text box

output_text = tk.Text(window, borderwidth=2, relief="solid", height=13)
output_text.pack(expand=True, side='top', anchor=tk.N)
output_text.bind("<Key>", disable_typing)

sys.stdout = StdoutRedirector(output_text)
output_text.insert(tk.END, f"|JHC Multipoint Precise Autoclicker|\n------ V1.0.0 Initial Build -------\n###################################{open_banner}\n###################################\n\nIf the script seems non responsive for any\nreason, press f6 then f7 to reset it.\n\nIf all coords are disabled, ctrl+c while\nfocused, it will not copy correctly.\nIf you need to copy coords, have at least\none toggle enabled and pause the script.\n\n", 'welcome')
output_text.tag_config('welcome', foreground='#cc8400', font=('Cascadia Code', 12, 'bold'))

##########################################################
# instruction box

instr_label = tk.Label(window, height=4, borderwidth=2, relief="solid", text="How to use: F6 to pause script, F7 to resume.\nToggle buttons remove that coord from the loop.\nFocus on window and Ctrl+c to copy current mouse coords.\nYou can minimize this window, but do not exit the minimized console.", font=('Arial', 9, 'bold'),)
instr_label.pack(side=tk.LEFT, anchor=tk.W)
instr_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=0, y=-417, relwidth=1)
instr_label.lift()
##########################################################
# minimize console

def minimize_console():
    if sys.platform == "win32":
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 6)

if __name__ == "__main__":
    minimize_console()
    print("Console window is minimized,\nscroll up for more info...")

##########################################################
# time variable text box

time_text = tk.Text(window, borderwidth=2, relief="solid", height=1, width=5)
time_text.pack(expand=True, fill=tk.BOTH)
time_text.insert(tk.END, "1.0")

time_text.bind('<Return>', disable_enter)

window.update_idletasks()
time_text.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-89, y=-20)

time_text_label = tk.Label(window, text="Current time between clicks:", font=('Arial', 12, 'bold'))
time_text_label.pack(side=tk.LEFT, anchor=tk.W)
time_text_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-145, y=-20)

second_box_label = tk.Label(window, text="secs.", font=('Arial', 12, 'bold'))
second_box_label.pack(side=tk.LEFT, anchor=tk.W)
second_box_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-30, y=-20)
##########################################################
# mouse position text box

mouse_pos = tk.Text(window, borderwidth=2, relief="solid", height=1, width=12)
mouse_pos.pack(expand=True, fill=tk.BOTH)
mouse_pos.insert(tk.END, f'{mouse_loc_x}, {mouse_loc_y}')

mouse_pos.bind("<Key>", disable_typing)
window.update_idletasks()
mouse_pos.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-33, y=-50)

mouse_pos_label = tk.Label(window, text='Current mouse coords are:', font=('Arial', 12, 'bold'))
mouse_pos_label.pack(side=tk.LEFT, anchor=tk.W)
mouse_pos_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-145, y=-50)

##########################################################
# screen size text box

size_box = tk.Text(window, borderwidth=2, relief='solid', height=1, width=12)
size_box.pack(expand=True, fill=tk.BOTH)
size_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-33, y=-80)
size_box.insert(tk.END, f'{screen_width}x{screen_height}' )

size_label = tk.Label(window, text='Current display resolution is:', font=('Arial', 12, 'bold'))
size_label.pack(side=tk.LEFT, anchor=tk.W)
size_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-145, y=-80)

##########################################################
# coord1 box

coord_1_box = tk.Text(window, borderwidth=2, relief="sunken", height=1, width=12)
coord_1_box.pack(expand=True, fill=tk.BOTH)
coord_1_box.insert(tk.END, str(middle_pos))

coord_1_box.bind('<Return>', disable_enter)

window.update_idletasks()
coord_1_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-3, y=-388)

coord_1_label = tk.Label(window, width=23, text='Coordinate position 1 is:', font=('Arial', 12, 'bold'), borderwidth=2, relief="ridge")
coord_1_label.pack(side=tk.LEFT, anchor=tk.W)
coord_1_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-110, y=-388)

##########################################################
# coord2 box

coord_2_box = tk.Text(window, borderwidth=2, relief="sunken", height=1, width=12)
coord_2_box.pack(expand=True, fill=tk.BOTH)
coord_2_box.insert(tk.END, str(middle_pos))

coord_2_box.bind('<Return>', disable_enter)

window.update_idletasks()
coord_2_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-3, y=-358)

coord_2_label = tk.Label(window, width=23, text='Coordinate position 2 is:', font=('Arial', 12, 'bold'), borderwidth=2, relief="ridge")
coord_2_label.pack(side=tk.LEFT, anchor=tk.W)
coord_2_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-110, y=-358)

##########################################################
# coord3 box

coord_3_box = tk.Text(window, borderwidth=2, relief="sunken", height=1, width=12)
coord_3_box.pack(expand=True, fill=tk.BOTH)
coord_3_box.insert(tk.END, str(middle_pos))

coord_3_box.bind('<Return>', disable_enter)

window.update_idletasks()
coord_3_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-3, y=-328)

coord_3_label = tk.Label(window, width=23, text='Coordinate position 3 is:', font=('Arial', 12, 'bold'), borderwidth=2, relief="ridge")
coord_3_label.pack(side=tk.LEFT, anchor=tk.W)
coord_3_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-110, y=-328)

##########################################################
# coord4 box

coord_4_box = tk.Text(window, borderwidth=2, relief="sunken", height=1, width=12)
coord_4_box.pack(expand=True, fill=tk.BOTH)
coord_4_box.insert(tk.END, str(middle_pos))

coord_4_box.bind('<Return>', disable_enter)

window.update_idletasks()
coord_4_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-3, y=-298)

coord_4_label = tk.Label(window, width=23, text='Coordinate position 4 is:', font=('Arial', 12, 'bold'), borderwidth=2, relief="ridge")
coord_4_label.pack(side=tk.LEFT, anchor=tk.W)
coord_4_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-110, y=-298)

##########################################################
# coord5 box

coord_5_box = tk.Text(window, borderwidth=2, relief="sunken", height=1, width=12)
coord_5_box.pack(expand=True, fill=tk.BOTH)
coord_5_box.insert(tk.END, str(middle_pos))

coord_5_box.bind('<Return>', disable_enter)

window.update_idletasks()
coord_5_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-3, y=-268)

coord_5_label = tk.Label(window, width=23, text='Coordinate position 5 is:', font=('Arial', 12, 'bold'), borderwidth=2, relief="ridge")
coord_5_label.pack(side=tk.LEFT, anchor=tk.W)
coord_5_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-110, y=-268)

##########################################################
# coord6 box

coord_6_box = tk.Text(window, borderwidth=2, relief="sunken", height=1, width=12)
coord_6_box.pack(expand=True, fill=tk.BOTH)
coord_6_box.insert(tk.END, str(middle_pos))

coord_6_box.bind('<Return>', disable_enter)

window.update_idletasks()
coord_6_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-3, y=-238)

coord_6_label = tk.Label(window, width=23, text='Coordinate position 6 is:', font=('Arial', 12, 'bold'), borderwidth=2, relief="ridge")
coord_6_label.pack(side=tk.LEFT, anchor=tk.W)
coord_6_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-110, y=-238)

##########################################################
# coord7 box

coord_7_box = tk.Text(window, borderwidth=2, relief="sunken", height=1, width=12)
coord_7_box.pack(expand=True, fill=tk.BOTH)
coord_7_box.insert(tk.END, str(middle_pos))

coord_7_box.bind('<Return>', disable_enter)

window.update_idletasks()
coord_7_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-3, y=-208)

coord_7_label = tk.Label(window, width=23, text='Coordinate position 7 is:', font=('Arial', 12, 'bold'), borderwidth=2, relief="ridge")
coord_7_label.pack(side=tk.LEFT, anchor=tk.W)
coord_7_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-110, y=-208)

##########################################################
# coord8 box

coord_8_box = tk.Text(window, borderwidth=2, relief="sunken", height=1, width=12)
coord_8_box.pack(expand=True, fill=tk.BOTH)
coord_8_box.insert(tk.END, str(middle_pos))

coord_8_box.bind('<Return>', disable_enter)

window.update_idletasks()
coord_8_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-3, y=-178)

coord_8_label = tk.Label(window, width=23, text='Coordinate position 8 is:', font=('Arial', 12, 'bold'), borderwidth=2, relief="ridge")
coord_8_label.pack(side=tk.LEFT, anchor=tk.W)
coord_8_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-110, y=-178)

##########################################################
# coord9 box

coord_9_box = tk.Text(window, borderwidth=2, relief="sunken", height=1, width=12)
coord_9_box.pack(expand=True, fill=tk.BOTH)
coord_9_box.insert(tk.END, str(middle_pos))

coord_9_box.bind('<Return>', disable_enter)

window.update_idletasks()
coord_9_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-3, y=-148)

coord_9_label = tk.Label(window, width=23, text='Coordinate position 9 is:', font=('Arial', 12, 'bold'), borderwidth=2, relief="ridge")
coord_9_label.pack(side=tk.LEFT, anchor=tk.W)
coord_9_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-110, y=-148)

##########################################################
# coord10 box

coord_10_box = tk.Text(window, borderwidth=2, relief="sunken", height=1, width=12)
coord_10_box.pack(expand=True, fill=tk.BOTH)
coord_10_box.insert(tk.END, str(middle_pos))

coord_10_box.bind('<Return>', disable_enter)

window.update_idletasks()
coord_10_box.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-3, y=-118)

coord_10_label = tk.Label(window, width=23, text='Coordinate position 10 is:', font=('Arial', 12, 'bold'), borderwidth=2, relief="ridge")
coord_10_label.pack(side=tk.LEFT, anchor=tk.W)
coord_10_label.place(relx=1.0, rely=1.0, anchor=tk.SE, bordermode='outside', x=-110, y=-118)

##########################################################
# coord disabling options

coord_label_list = (coord_1_label,
                    coord_2_label,
                    coord_3_label,
                    coord_4_label,
                    coord_5_label,
                    coord_6_label,
                    coord_7_label,
                    coord_8_label,
                    coord_9_label,
                    coord_10_label)

button_coordinates = [
    (-350, -387), #1
    (-350, -357), #2
    (-350, -327), #3
    (-350, -297), #4
    (-350, -267), #5
    (-350, -237), #6
    (-350, -207), #7
    (-350, -177), #8
    (-350, -147), #9
    (-350, -117), #10
]

def create_coord_widgets():
    global window
    for i, (x, y) in enumerate(button_coordinates):
        button = tk.Button(window, text='Toggle', command=lambda index=i: toggle_coord_state(index))
        button.place(relx=1.0, rely=1.0, anchor=tk.SE, x=x, y=y)
        coord_buttons.append(button)
        button.lift()
        button.config(bg='red')

create_coord_widgets()

##########################################################
# multithreading

stop_thread = thr.Thread(target=e_stop_act, daemon=True)
stop_thread.start()

mouse_thread = thr.Thread(target=get_mouse_pos, daemon=True)
mouse_thread.start()

start_threads()

##########################################################
# windows main loop

def update_mouse_position():
    mouse_pos.delete('1.0', tk.END)
    mouse_pos.insert(tk.END, f'{mouse_loc_x}, {mouse_loc_y}')
    window.after(100, update_mouse_position)

update_mouse_position()
update_coord_text_boxes()
main_loop()
window.mainloop()